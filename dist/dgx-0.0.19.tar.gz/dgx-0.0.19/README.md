# Generador de proyecto API para dealergeek

Generar release

```
python setup.py sdist

```

Subir a Pip

```
twine upload dist/*
```